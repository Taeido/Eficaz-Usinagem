PROTÓTIPO — Site Eficaz Usinagem de Precisão

Como testar localmente:
1) Abra a pasta e dê duplo clique em "index.html".
   - Navegadores modernos carregam normalmente.

Como publicar rapidamente:
Opção A) Hospedagem simples (recomendado para começar)
- Suba a pasta inteira para um servidor (cPanel / Hostinger / Locaweb / etc).
- Garanta que o "index.html" esteja na raiz do domínio.

Opção B) GitHub Pages
- Crie um repositório e envie todos os arquivos.
- Ative GitHub Pages apontando para a branch principal.

O que você deve trocar (prioridade):
1) Logo: assets/img/logo-placeholder.svg → substitua pelo logo oficial em PNG/SVG.
2) Fotos: adicione imagens reais em assets/img e substitua no HTML (hero/serviços).
3) E-mail: no index.html, ajuste data-mailto no formulário e os links mailto:.
4) WhatsApp: ajuste o número no link wa.me (já está como 5511944508711).
5) SEO: troque o title/description e adicione "og:" meta tags se desejar.

Observação:
- Os PDFs em /docs foram copiados a partir dos arquivos fornecidos pelo usuário nesta conversa.
